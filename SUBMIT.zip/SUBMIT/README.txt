Zeb Carty and Michael McInerney

Program that outputs statistics for tcpdump files.

To run:
run 'make wireview'
run './wireview <FILENAME>' with pcap file you want statistics for

wireview will output statistics in the terminal