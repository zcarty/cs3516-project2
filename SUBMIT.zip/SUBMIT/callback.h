#include "include.h"

void callback(u_char *args, const struct pcap_pkthdr *header,
    const u_char *packet);

void print_output();